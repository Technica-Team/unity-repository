﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Security.Cryptography;
using UnityEngine;

public class Bunny : MonoBehaviour
{
    public Rigidbody2D rb;
    public float movingSpeed;
    public float hopHeight;

    public GameObject wall_up;
    public GameObject wall_down;

    //another yeehaw?
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity = new Vector2(movingSpeed, rb.velocity.y);

        if (Input.GetMouseButtonDown(0))
        {
            rb.velocity = new Vector2(rb.velocity.x, hopHeight);
        }

        if (transform.position.y > 18 || transform.position.y < -19)
        {
            Death();
        }
    }

    public void Death()
    {
        rb.velocity = Vector3.zero;
        transform.position = new Vector2(0, 0);
    }
}

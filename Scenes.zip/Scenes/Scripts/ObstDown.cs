﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ObstDown : MonoBehaviour
{
    
    private Bunny bunny;

    // Start is called before the first frame update
    void Start()
    {
        bunny = FindObjectOfType<Bunny>();
    }

    // Update is called once per frame
    void Update()
    {
        if (bunny.transform.position.x - transform.position.x > 30)
        {
            /*
            float xRan = Random.Range(-5, 10);
            float yRan = Random.Range(-5, 10);
            float gapRan = Random.Range(0, 3);

            Instantiate(gameObject, new Vector2(bunny.transform.position.x + 30 + xRan, -11 + yRan), transform.rotation);
            Instantiate(wallDown, new Vector2(bunny.transform.position.x + 30 + xRan, 12 + gapRan + yRan), transform.rotation); */
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            bunny.Death();
        }
    }
}

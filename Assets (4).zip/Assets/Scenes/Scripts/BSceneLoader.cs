﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneLoader : Monobehaviour
{

    public void LoadScene(int level)
    {
        Application.LoadLevel(1);
    }
}

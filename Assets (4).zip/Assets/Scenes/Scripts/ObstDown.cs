﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ObstDown : MonoBehaviour
{
    
    private Bunny bunny;

    // Start is called before the first frame update
    void Start()
    {
        bunny = FindObjectOfType<Bunny>();
    }

    // Update is called once per frame
    void Update()
    {
        if (bunny.transform.position.x - transform.position.x > 30)
        {
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            bunny.Death();
        }
    }
}

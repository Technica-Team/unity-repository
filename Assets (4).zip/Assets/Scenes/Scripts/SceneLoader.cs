﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BSceneLoader : Monobehaviour
{

    public void LoadScene(int level)
    {
        Application.LoadLevel(1);
    }
}

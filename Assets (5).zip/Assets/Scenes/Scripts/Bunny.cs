﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics.Contracts;
using System.Security.Cryptography;
using UnityEngine;

public class Bunny : MonoBehaviour
{
    public Rigidbody2D rb;
    public float movingSpeed;
    public float hopHeight;

    public GameObject wall_up;
    public GameObject wall_down;
    public GameObject gameOver;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
       
        gameOver.SetActive(false);
        BuildLevel();
    }

    void BuildLevel()
    {
        Instantiate(wall_down, new Vector3(100, 100), transform.rotation);
        Instantiate(wall_up, new Vector3(100, -100), transform.rotation);

        Instantiate(wall_down, new Vector3(560, 95), transform.rotation);
        Instantiate(wall_up, new Vector3(560, -100), transform.rotation);

        Instantiate(wall_down, new Vector3(600, 100), transform.rotation);
        Instantiate(wall_up, new Vector3(600, -95), transform.rotation);

        Instantiate(wall_down, new Vector3(700, 80), transform.rotation);
        Instantiate(wall_up, new Vector3(700, -100), transform.rotation);

        Instantiate(wall_down, new Vector3(601, 90), transform.rotation);
        Instantiate(wall_up, new Vector3(601, -100), transform.rotation);
    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity = new Vector2(movingSpeed, rb.velocity.y);

        if (Input.GetMouseButtonDown(0))
        {
            rb.velocity = new Vector2(rb.velocity.x, hopHeight);
        }

        if (transform.position.y > 18 || transform.position.y < -19)
        {
            Death();
        }
    }

    public void Death()
    {
        rb.velocity = Vector3.zero;
        transform.position = new Vector2(0, 0);
        BuildLevel();
        movingSpeed = 0;
        gameOver.SetActive(true);
    }
}
